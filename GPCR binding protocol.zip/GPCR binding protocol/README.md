# GPCR-small-ligand-binding-protocol
Plumed input file to run MW-MetaD simulations with the  binding/unbinding protocol for GPCRs small ligands
For the ADRB2-adrenaline binary system, starting structure (adr_bin_conf.gro) and topology files are provided. Plumed input file to run MW-MetaD with the binding/unbinding protocol is also provided (plumed.dat)
